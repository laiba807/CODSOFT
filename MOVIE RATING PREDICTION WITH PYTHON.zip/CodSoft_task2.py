import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix

# Loading the dataset
file_path = r'C:\Users\DELL 5490\Downloads\IMDb Movies India.csv'
data = pd.read_csv(file_path, encoding='latin1')
print("Basic information about the dataset:")
print(data.info())

# Handling missing values
print("\nHandling missing values:")
print("Before handling missing values:")
print(data.isnull().sum())

# Dropping rows with missing value
data.dropna(inplace=True)

# Check missing values after dropping rows
print("\nAfter dropping rows with missing values:")
print(data.isnull().sum())

# Feature Engineering: Creating binary indicators for popular genres
popular_genres = ['Drama', 'Action', 'Comedy', 'Thriller', 'Romance']
for genre in popular_genres:
    data[genre] = data['Genre'].apply(lambda x: 1 if genre in x else 0)

# Print characteristics of feature engineering
print("\nFeature Engineering Characteristics:")
for genre in popular_genres:
    genre_count = data[genre].sum()
    print(f"{genre}: {genre_count} movies")

# Visualize feature engineering characteristics
plt.figure(figsize=(10, 6))
colors = sns.color_palette('husl', len(popular_genres))
sns.barplot(x=popular_genres, y=[data[genre].sum() for genre in popular_genres], hue=popular_genres, palette=colors, legend=False)
plt.title('Distribution of Popular Genres')
plt.xlabel('Genre')
plt.ylabel('Number of Movies')
plt.xticks(rotation=45)
plt.show()

# Filter genres with 0 or fewer than 7 ratings
genre_counts = data['Genre'].value_counts()
selected_genres = genre_counts[genre_counts > 7].index

# Filter the dataframe to keep only selected genres
data_filtered = data[data['Genre'].isin(selected_genres)]

# Saving preprocessed dataset
preprocessed_filepath = "C:/Users/DELL 5490/Desktop/preprocessed_dataset.csv"
data_filtered.to_csv(preprocessed_filepath, index=False)
print("\nPreprocessing completed and saved to:", preprocessed_filepath)

# Loading the preprocessed dataset
data_filtered = pd.read_csv(preprocessed_filepath)

# Predicting the ratings according to the genre using confusion matrix 
bins = [0, 4, 6, 8, 10]  
labels = ['Very Low', 'Low', 'Moderate', 'High']  
data_filtered['Rating_Category'] = pd.cut(data_filtered['Ratings'], bins=bins, labels=labels)
X = data_filtered[popular_genres]  # Using the engineered features
y = data_filtered['Rating_Category']  
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression()
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
# Calculating accuracy
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)
# Confusion matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(conf_matrix)
# Plotting confusion matrix
plt.figure(figsize=(8, 6))
sns.heatmap(conf_matrix, annot=True, cmap='Blues', fmt='d', xticklabels=model.classes_, yticklabels=model.classes_)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()

#barlot visuals for predict ratings according to Genre
preprocessed_filepath = "C:/Users/DELL 5490/Desktop/preprocessed_dataset.csv"
data_filtered = pd.read_csv(preprocessed_filepath)

data_filtered = data_filtered[data_filtered['Ratings'] >= 8]
pivot_data = data_filtered.pivot_table(index='Genre', columns='Ratings', aggfunc='size', fill_value=0)
fig, ax = plt.subplots(figsize=(12, 8))
pivot_data.plot(kind='bar', stacked=True, cmap='viridis', ax=ax)
ax.set_title('Count of Ratings by Genre (Starting from 8)')
ax.set_xlabel('Genre')
ax.set_ylabel('Count')
ax.legend(title='Ratings')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Scatterplot visual of predicting ratings according to Director
director_ratings = data_filtered.groupby('Director')['Ratings'].mean()
director_ratings_filtered = director_ratings[director_ratings >= 8.8]
filtered_data = data_filtered[data_filtered['Director'].isin(director_ratings_filtered.index)]
fig, ax = plt.subplots(figsize=(12, 8))
for director, group in filtered_data.groupby('Director'):
    ax.scatter(group['Ratings'], [director] * len(group), label=director, alpha=0.7)
ax.set_title('Ratings by Director')
ax.set_xlabel('Ratings')
ax.set_ylabel('Director')
ax.legend(title='Director')
plt.show()