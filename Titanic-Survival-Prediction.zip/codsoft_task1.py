import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_curve, auc

# Loading Titanic dataset
path = r"C:\Users\DELL 5490\Downloads\Titanic-Dataset.csv"
titanic = pd.read_csv(path)

# Preprocessing the data of titanic dataset
titanic.dropna(subset=['Age', 'Sex', 'Pclass'], inplace=True)
titanic['Sex'] = titanic['Sex'].map({'male': 0, 'female': 1})

# Feature selection performing
features = ['Age', 'Sex', 'Pclass', 'Fare']
a = titanic[features]
b = titanic['Survived']

# Splitting the data into training and testing sets for task 
a_train, a_test, b_train, b_test = train_test_split(a, b, test_size=0.2, random_state=42)

# Building and training the model according to the dataset
model = RandomForestClassifier(random_state=42)
model.fit(a_train, b_train)

# Making predictions 
predictions = model.predict(a_test)

# Evaluating the model
accuracy = accuracy_score(b_test, predictions)
print("Accuracy:", accuracy)
print("\nClassification Report:")
print(classification_report(b_test, predictions))

# Confusion Matrix
conf_matrix = confusion_matrix(b_test, predictions)
plt.figure(figsize=(6, 4))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap="Blues")
plt.title("Confusion Matrix")
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()

# Survival count by features
plt.figure(figsize=(16, 8))
plt.subplot(2, 2, 1)
sns.countplot(x='Sex', hue='Survived', data=titanic)
plt.title('Survival Count by Sex')

plt.subplot(2, 2, 2)
sns.countplot(x='Pclass', hue='Survived', data=titanic)
plt.title('Survival Count by Pclass')

plt.subplot(2, 2, 3)
sns.histplot(x='Age', hue='Survived', data=titanic, kde=True)
plt.title('Survival Count by Age')

plt.subplot(2, 2, 4)
sns.histplot(x='Fare', hue='Survived', data=titanic, kde=True)
plt.title('Survival Count by Fare')
plt.tight_layout()
plt.show()

# Excluding non-numeric columns before computing correlation matrix
numeric_columns = titanic.select_dtypes(include=['number']).columns
correlation_matrix = titanic[numeric_columns].corr()

# Correlation Heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm")
plt.title('Correlation Heatmap')
plt.show()

# ROC Curve
fpr, tpr, thresholds = roc_curve(b_test, predictions)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()
